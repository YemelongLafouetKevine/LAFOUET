The data in this archive was unpublished on the date listed for the archive, because it was replaced with updated data.

You will need Adobe Acrobat Reader to view the Data Dictionary file. You can download this software from Adobe's web site. To get the software at no cost, copy and paste the link below into the browser address bar. It will take you to the Adobe Acrobat Reader download site.
https://get.adobe.com/reader/
